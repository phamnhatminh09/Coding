document.addEventListener("DOMContentLoaded", () => {
    const CART_KEY = "teslaOrderCart";
    const LEGACY_KEY = "teslaOrderSelection";
    const parsePrice = (value) => Number(String(value || "0").replace(/[^0-9.-]+/g, "")) || 0;
    const formatPrice = (num) => `$${Number(num || 0).toLocaleString("en-US")}`;
    const getCart = () => {
        try {
            const parsed = JSON.parse(localStorage.getItem(CART_KEY) || "[]");
            return Array.isArray(parsed) ? parsed : [];
        } catch (error) {
            return [];
        }
    };
    const setCart = (items) => {
        localStorage.setItem(CART_KEY, JSON.stringify(items));
    };
    const header = document.querySelector("header");
    if (header) {
        window.addEventListener("scroll", () => {
            if (window.scrollY > 50) {
                header.style.background = "#0b0b0b";
                header.style.boxShadow = "0 2px 10px rgba(0,0,0,0.5)";
            } else {
                header.style.background = "rgba(8, 8, 8, 0.97)";
                header.style.boxShadow = "none";
            }
        });
    }

    const specToggle = document.querySelector(".model-y-specs-head .spec-toggle");
    if (specToggle) {
        const buttons = specToggle.querySelectorAll("button[data-variant]");
        const panels = document.querySelectorAll(".model-y-specs-panel[data-variant]");
        buttons.forEach((btn) => {
            btn.addEventListener("click", () => {
                const variant = btn.getAttribute("data-variant");
                buttons.forEach((b) => b.classList.toggle("active", b === btn));
                panels.forEach((panel) => {
                    panel.hidden = panel.getAttribute("data-variant") !== variant;
                });
            });
        });
    }

    const slides = document.querySelectorAll(".slide");
    if (slides.length > 1) {
        let index = 0;
        setInterval(() => {
            slides[index].classList.remove("active");
            index = (index + 1) % slides.length;
            slides[index].classList.add("active");
        }, 4000);
    }

    const contactForm = document.getElementById("contact-form");
    if (contactForm) {
        const successMessage = document.getElementById("contact-success");
        contactForm.addEventListener("submit", (event) => {
            event.preventDefault();
            const requiredFields = contactForm.querySelectorAll("[required]");
            let valid = true;

            requiredFields.forEach((field) => {
                if (!field.value.trim()) {
                    valid = false;
                }
            });

            if (!valid) {
                alert("Please fill in all required fields.");
                return;
            }

            if (successMessage) {
                successMessage.style.display = "block";
            }
            contactForm.reset();
        });
    }

    const inventoryButtons = document.querySelectorAll("[data-order-model]");
    if (inventoryButtons.length) {
        inventoryButtons.forEach((button) => {
            button.addEventListener("click", () => {
                const payload = {
                    model: button.getAttribute("data-order-model") || "Model 3",
                    trim: button.getAttribute("data-order-trim") || "Base",
                    price: button.getAttribute("data-order-price") || "$38,990",
                    image: button.getAttribute("data-order-image") || "mod3.png",
                    quantity: 1
                };
                const parentScope = button.closest(".inventory-card, .order-config-panel");
                const homeChargerCheckbox = parentScope ? parentScope.querySelector("[data-home-charger]") : null;
                if (homeChargerCheckbox && homeChargerCheckbox.checked) {
                    const upgradedPrice = parsePrice(payload.price) + 450;
                    payload.price = formatPrice(upgradedPrice);
                    payload.trim = `${payload.trim} + Home Charger`;
                }
                const action = button.getAttribute("data-order-action") || "checkout";
                const cart = getCart();
                const existing = cart.find((item) =>
                    item.model === payload.model &&
                    item.trim === payload.trim &&
                    item.price === payload.price &&
                    item.image === payload.image
                );
                if (existing) {
                    existing.quantity = (Number(existing.quantity) || 1) + 1;
                } else {
                    cart.push(payload);
                }
                setCart(cart);
                if (action === "add") {
                    alert(`${payload.model} added to cart.`);
                    return;
                }
                window.location.href = "payment.html";
            });
        });
    }

    const inventoryGrid = document.querySelector(".inventory-grid");
    if (inventoryGrid) {
        const modelFilters = document.querySelectorAll(".inventory-model-filter");
        const trimFilters = document.querySelectorAll(".filter-pill[data-trim]");
        const cityFilters = document.querySelectorAll(".city-pill[data-city]");
        const cityLabel = document.getElementById("inventory-city-label");
        const sortSelect = document.getElementById("inventory-sort");
        const resetButton = document.getElementById("inventory-reset");
        const loadMoreButton = document.getElementById("inventory-load-more");
        let hasFilterInteraction = false;
        const pageSize = 6;
        let visibleCount = pageSize;

        const applyInventoryState = () => {
            const activeModels = Array.from(modelFilters)
                .filter((filter) => filter.checked)
                .map((filter) => filter.value);
            const activeTrimButton = Array.from(trimFilters).find((btn) => btn.classList.contains("active"));
            const activeTrim = activeTrimButton ? activeTrimButton.getAttribute("data-trim") : "";
            const activeCityButton = Array.from(cityFilters).find((btn) => btn.classList.contains("active"));
            const activeCity = activeCityButton ? activeCityButton.getAttribute("data-city") : "";
            if (cityLabel && activeCity) {
                cityLabel.textContent = activeCity;
            } else if (cityLabel) {
                cityLabel.textContent = "All Cities";
            }
            const cards = Array.from(inventoryGrid.querySelectorAll(".inventory-card"));

            cards.forEach((card) => {
                if (!hasFilterInteraction || (!activeModels.length && !activeTrim)) {
                    const cardCity = card.getAttribute("data-city") || "";
                    card.style.display = !activeCity || cardCity === activeCity ? "" : "none";
                    return;
                }
                const model = card.getAttribute("data-model") || "";
                const trim = card.getAttribute("data-trim") || "";
                const cardCity = card.getAttribute("data-city") || "";
                const modelMatch = !activeModels.length || activeModels.includes(model);
                const trimMatch = !activeTrim || trim === activeTrim;
                const cityMatch = !activeCity || cardCity === activeCity;
                card.style.display = modelMatch && trimMatch && cityMatch ? "" : "none";
            });

            const sortedVisible = cards
                .filter((card) => card.style.display !== "none")
                .sort((a, b) => {
                    const priceA = Number(a.getAttribute("data-price")) || 0;
                    const priceB = Number(b.getAttribute("data-price")) || 0;
                    if (sortSelect && sortSelect.value === "price-desc") {
                        return priceB - priceA;
                    }
                    return priceA - priceB;
                });

            sortedVisible.forEach((card) => inventoryGrid.appendChild(card));

            sortedVisible.forEach((card, index) => {
                card.style.display = index < visibleCount ? "" : "none";
            });

            if (loadMoreButton) {
                loadMoreButton.style.display = sortedVisible.length > visibleCount ? "" : "none";
            }
        };

        modelFilters.forEach((filter) => {
            filter.addEventListener("change", () => {
                hasFilterInteraction = true;
                visibleCount = pageSize;
                applyInventoryState();
            });
        });
        if (sortSelect) {
            sortSelect.addEventListener("change", () => {
                visibleCount = pageSize;
                applyInventoryState();
            });
        }
        trimFilters.forEach((button) => {
            button.addEventListener("click", () => {
                hasFilterInteraction = true;
                const wasActive = button.classList.contains("active");
                trimFilters.forEach((btn) => btn.classList.remove("active"));
                if (!wasActive) {
                    button.classList.add("active");
                }
                visibleCount = pageSize;
                applyInventoryState();
            });
        });
        cityFilters.forEach((button) => {
            button.addEventListener("click", () => {
                hasFilterInteraction = true;
                cityFilters.forEach((btn) => btn.classList.toggle("active", btn === button));
                visibleCount = pageSize;
                applyInventoryState();
            });
        });
        if (resetButton) {
            resetButton.addEventListener("click", () => {
                modelFilters.forEach((filter) => {
                    filter.checked = false;
                });
                trimFilters.forEach((btn) => btn.classList.remove("active"));
                const defaultCity = cityFilters[0];
                cityFilters.forEach((btn) => btn.classList.toggle("active", btn === defaultCity));
                visibleCount = pageSize;
                applyInventoryState();
            });
        }
        if (loadMoreButton) {
            loadMoreButton.addEventListener("click", () => {
                visibleCount += pageSize;
                applyInventoryState();
            });
        }
        applyInventoryState();
    }

    const paintChips = document.querySelectorAll(".config-chip");
    if (paintChips.length) {
        const getPaintFilter = (paintName) => {
            const paint = (paintName || "").toLowerCase();
            const filterMap = {
                white: "brightness(1.08) saturate(0.85)",
                "satin-white": "brightness(1.08) saturate(0.9)",
                black: "brightness(0.58) saturate(0.7)",
                "satin-black": "brightness(0.52) saturate(0.65)",
                blue: "hue-rotate(160deg) saturate(1.35) brightness(0.92)",
                red: "hue-rotate(0deg) saturate(1.25) brightness(0.98)",
                silver: "saturate(0.45) brightness(1.02)",
                grey: "saturate(0.4) brightness(0.95)",
                stainless: "saturate(0.25) brightness(1.02) contrast(1.05)"
            };
            return filterMap[paint] || "none";
        };

        const applySelectedPaint = (chipRow) => {
            if (!chipRow) {
                return;
            }
            const activeChip = chipRow.querySelector(".config-chip.active");
            const paint = activeChip ? activeChip.getAttribute("data-paint") : "";
            const layout = chipRow.closest(".order-config-layout");
            const visualImage = layout ? layout.querySelector(".order-config-visual img") : null;
        };

        paintChips.forEach((chip) => {
            chip.addEventListener("click", () => {
                const chipRow = chip.closest(".config-chip-row");
                if (!chipRow) {
                    return;
                }
                const siblings = chipRow.querySelectorAll(".config-chip");
                siblings.forEach((item) => item.classList.toggle("active", item === chip));
                applySelectedPaint(chipRow);
            });
        });

        document.querySelectorAll(".config-chip-row").forEach((chipRow) => {
            applySelectedPaint(chipRow);
        });
    }

    const wheelTiles = document.querySelectorAll(".config-tiles .config-tile");
    if (wheelTiles.length) {
        wheelTiles.forEach((tile) => {
            tile.addEventListener("click", () => {
                const group = tile.closest(".config-tiles");
                if (!group) {
                    return;
                }
                const siblings = group.querySelectorAll(".config-tile");
                siblings.forEach((item) => item.classList.toggle("active", item === tile));
            });
        });
    }

    const paymentCartItems = document.getElementById("payment-cart-items");
    if (paymentCartItems) {
        let cart = getCart();
        if (!cart.length) {
            const storedSelection = localStorage.getItem(LEGACY_KEY);
            if (storedSelection) {
                try {
                    const legacy = JSON.parse(storedSelection);
                    cart = [{ ...legacy, quantity: Number(legacy.quantity) || 1 }];
                    setCart(cart);
                    localStorage.removeItem(LEGACY_KEY);
                } catch (error) {
                    localStorage.removeItem(LEGACY_KEY);
                }
            }
        }

        const paymentTotal = document.getElementById("payment-total");
        const renderPaymentCart = () => {
            if (!cart.length) {
                paymentCartItems.innerHTML = '<p class="payment-empty">No vehicles selected yet.</p>';
            } else {
                paymentCartItems.innerHTML = cart.map((item, index) => {
                    const qty = Math.max(1, Number(item.quantity) || 1);
                    const unitPrice = parsePrice(item.price);
                    const lineTotal = unitPrice * qty;
                    return `
                    <article class="payment-cart-item">
                        <img src="${item.image || "mod3.png"}" alt="${item.model || "Model"}">
                        <div>
                            <h3>${item.model || "Model"}</h3>
                            <p>${item.trim || "Base"}</p>
                            <div class="payment-qty-row">
                                <button type="button" class="qty-btn" data-cart-idx="${index}" data-qty-action="dec">-</button>
                                <span class="qty-value">${qty}</span>
                                <button type="button" class="qty-btn" data-cart-idx="${index}" data-qty-action="inc">+</button>
                            </div>
                            <small>Unit: ${formatPrice(unitPrice)}</small>
                            <strong>${formatPrice(lineTotal)}</strong>
                        </div>
                    </article>
                    `;
                }).join("");
            }
            if (paymentTotal) {
                const total = cart.reduce((sum, item) => {
                    const qty = Math.max(1, Number(item.quantity) || 1);
                    return sum + parsePrice(item.price) * qty;
                }, 0);
                paymentTotal.textContent = formatPrice(total);
            }
            setCart(cart);
        };

        renderPaymentCart();

        paymentCartItems.addEventListener("click", (event) => {
            const target = event.target;
            if (!(target instanceof HTMLElement)) {
                return;
            }
            const button = target.closest(".qty-btn");
            if (!button) {
                return;
            }
            const idx = Number(button.getAttribute("data-cart-idx"));
            const action = button.getAttribute("data-qty-action");
            if (!Number.isInteger(idx) || idx < 0 || idx >= cart.length) {
                return;
            }

            const currentQty = Math.max(1, Number(cart[idx].quantity) || 1);
            if (action === "inc") {
                cart[idx].quantity = currentQty + 1;
            } else if (action === "dec") {
                if (currentQty <= 1) {
                    cart.splice(idx, 1);
                } else {
                    cart[idx].quantity = currentQty - 1;
                }
            }
            renderPaymentCart();
        });

        const orderForm = document.getElementById("order-form");
        if (orderForm) {
            orderForm.addEventListener("submit", (event) => {
                event.preventDefault();
                if (!cart.length) {
                    alert("Please add at least one vehicle to cart.");
                    return;
                }
                alert("Order completed");
                localStorage.removeItem(CART_KEY);
                localStorage.removeItem(LEGACY_KEY);
                window.location.href = "index.html";
            });
        }
    }
});
