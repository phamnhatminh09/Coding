/**
 * Build the WordPress-ready LMS AI HTML fragment from the current source page.
 *
 * The output is intended for a WordPress Custom HTML block. It keeps the OES
 * wrapper used by the live theme while preserving the publishable block shape.
 */
const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const SOURCE_HTML = path.join(ROOT, 'LMS AI.html');
const SOURCE_CSS = path.join(ROOT, 'styles.css');
const SOURCE_JS = path.join(ROOT, 'script.js');
const OUTPUT_HTML = path.join(ROOT, 'LMS AI-wordpress.html');

const SCOPE = '.oes.lms-ai-page';

function readUtf8(filePath) {
  return fs.readFileSync(filePath, 'utf8');
}

function extractBetween(source, startPattern, endPattern, label) {
  const start = source.match(startPattern);
  if (!start) {
    throw new Error(`Could not find ${label} start`);
  }

  const contentStart = start.index + start[0].length;
  const rest = source.slice(contentStart);
  const end = rest.match(endPattern);
  if (!end) {
    throw new Error(`Could not find ${label} end`);
  }

  return rest.slice(0, end.index).trim();
}

function findMatchingBrace(source, openIndex) {
  let depth = 0;
  let quote = null;

  for (let i = openIndex; i < source.length; i += 1) {
    const char = source[i];
    const previous = source[i - 1];

    if (quote) {
      if (char === quote && previous !== '\\') {
        quote = null;
      }
      continue;
    }

    if (char === '"' || char === "'") {
      quote = char;
      continue;
    }

    if (char === '{') depth += 1;
    if (char === '}') {
      depth -= 1;
      if (depth === 0) return i;
    }
  }

  throw new Error('Unbalanced CSS braces');
}

function splitSelectorList(selectorText) {
  const selectors = [];
  let current = '';
  let depth = 0;
  let quote = null;

  for (let i = 0; i < selectorText.length; i += 1) {
    const char = selectorText[i];
    const previous = selectorText[i - 1];

    if (quote) {
      current += char;
      if (char === quote && previous !== '\\') {
        quote = null;
      }
      continue;
    }

    if (char === '"' || char === "'") {
      quote = char;
      current += char;
      continue;
    }

    if (char === '(' || char === '[') depth += 1;
    if (char === ')' || char === ']') depth -= 1;

    if (char === ',' && depth === 0) {
      selectors.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }

  if (current.trim()) selectors.push(current.trim());
  return selectors;
}

function scopeSelector(selector) {
  if (!selector) return selector;
  if (selector.startsWith(SCOPE)) return selector;

  if (selector === ':root' || selector === 'html' || selector === 'body') {
    return SCOPE;
  }

  if (selector.startsWith(':root ')) {
    return selector.replace(':root', SCOPE);
  }

  if (selector.startsWith('html ') || selector.startsWith('body ')) {
    return `${SCOPE} ${selector.slice(selector.indexOf(' ') + 1)}`;
  }

  return `${SCOPE} ${selector}`;
}

function scopeCss(css) {
  let output = '';
  let cursor = 0;

  while (cursor < css.length) {
    const openIndex = css.indexOf('{', cursor);
    if (openIndex === -1) {
      output += css.slice(cursor);
      break;
    }

    const selector = css.slice(cursor, openIndex).trim();
    const closeIndex = findMatchingBrace(css, openIndex);
    const body = css.slice(openIndex + 1, closeIndex);

    if (!selector) {
      cursor = closeIndex + 1;
      continue;
    }

    if (selector.startsWith('@')) {
      const lower = selector.toLowerCase();
      if (
        lower.startsWith('@media') ||
        lower.startsWith('@supports') ||
        lower.startsWith('@container') ||
        lower.startsWith('@document')
      ) {
        output += `${selector} {\n${scopeCss(body)}\n}\n`;
      } else {
        output += `${selector} {${body}}\n`;
      }
    } else {
      const scopedSelector = splitSelectorList(selector)
        .map(scopeSelector)
        .join(',\n');
      output += `${scopedSelector} {${body}}\n`;
    }

    cursor = closeIndex + 1;
  }

  return output.trim();
}

function buildScopedCss(sourceCss) {
  const importPattern = /@import\s+url\([^)]+\)\s*;/g;
  const imports = sourceCss.match(importPattern) || [];
  const cssWithoutImports = sourceCss
    .replace(importPattern, '')
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .trim();

  const scopedCss = scopeCss(cssWithoutImports);
  return [
    ...imports,
    `${SCOPE} {`,
    '  min-height: 100%;',
    '  background: var(--body-color);',
    '  color: var(--text-color);',
    '  font-family: var(--body-font);',
    '  font-size: var(--normal-font-size);',
    '  line-height: 1.65;',
    '  overflow-x: hidden;',
    '}',
    `${SCOPE} #container {`,
    '  width: 100%;',
    '  overflow: hidden;',
    '}',
    '.top-form {',
    '  display: none !important;',
    '}',
    scopedCss,
  ].join('\n\n');
}

function buildScopedScript(sourceJs) {
  return sourceJs
    .replace(
      "'use strict';",
      [
        "'use strict';",
        '',
        "  const root = document.currentScript.closest('.oes.lms-ai-page') || document;",
        "  const byId = id => root.querySelector(`#${id}`);",
      ].join('\n')
    )
    .replace(/\bdocument\.getElementById\(/g, 'byId(')
    .replace(/\bdocument\.querySelectorAll\(/g, 'root.querySelectorAll(')
    .replace(/\bdocument\.querySelector\(/g, 'root.querySelector(')
    .replace(
      '  const handleHeaderScroll = () => {\n    if (window.scrollY > 60) {',
      '  const handleHeaderScroll = () => {\n    if (!header) return;\n    if (window.scrollY > 60) {'
    );
}

function buildWordPressHtml() {
  const sourceHtml = readUtf8(SOURCE_HTML);
  const sourceCss = readUtf8(SOURCE_CSS);
  const sourceJs = readUtf8(SOURCE_JS);

  const mainContent = extractBetween(sourceHtml, /<main\b[^>]*>/i, /<\/main>/i, 'main content');
  const backToTop = extractBetween(
    sourceHtml,
    /<!--\s*Back to top button\s*-->/i,
    /<script\s+src=["']script\.js["']\s*><\/script>/i,
    'back-to-top button'
  );

  const scopedCss = buildScopedCss(sourceCss);
  const scopedJs = buildScopedScript(sourceJs);

  return [
    '<!-- wp:html -->',
    '<link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">',
    '<style>',
    scopedCss,
    '</style>',
    '',
    '<div class="oes lms-ai-page">',
    '<div id="container">',
    '<main class="lms-ai-content">',
    mainContent,
    '</main>',
    '',
    backToTop,
    '</div>',
    '<script>',
    scopedJs,
    '</script>',
    '</div>',
    '<!-- /wp:html -->',
    '',
  ].join('\n');
}

function validate(output) {
  const requiredSnippets = [
    '<!-- wp:html -->',
    '<!-- /wp:html -->',
    '<div class="oes lms-ai-page">',
    '<div id="container">',
    '<section class="hero" id="hero">',
    '<section class="contact section" id="contact">',
    'OES WeLearning AI',
  ];

  for (const snippet of requiredSnippets) {
    if (!output.includes(snippet)) {
      throw new Error(`Generated output is missing required snippet: ${snippet}`);
    }
  }

  if (/<\/?(?:html|head|body)\b/i.test(output)) {
    throw new Error('Generated output must be a WordPress fragment, not a full HTML document');
  }
}

const output = buildWordPressHtml();
validate(output);
fs.writeFileSync(OUTPUT_HTML, output, 'utf8');

console.log('Generated:', OUTPUT_HTML);
console.log('Size:', `${(fs.statSync(OUTPUT_HTML).size / 1024).toFixed(1)} KB`);
